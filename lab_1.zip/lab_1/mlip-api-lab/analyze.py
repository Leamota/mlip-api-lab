# analyze.py
import os
import time
from typing import List

# Optional: load from .env during local dev; keep .env out of Git
try:
    from dotenv import load_dotenv
    load_dotenv()
except Exception:
    pass

from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from msrest.authentication import CognitiveServicesCredentials
from azure.cognitiveservices.vision.computervision.models import OperationStatusCodes

# --- Credentials from env (DO NOT hard-code) ---
AZURE_CV_ENDPOINT = os.getenv("AZURE_CV_ENDPOINT")
AZURE_CV_KEY = os.getenv("AZURE_CV_KEY")

if not AZURE_CV_ENDPOINT or not AZURE_CV_KEY:
    raise RuntimeError("Missing AZURE_CV_ENDPOINT or AZURE_CV_KEY. Set them in your environment or .env (not committed).")

# --- Client ---
_client = ComputerVisionClient(AZURE_CV_ENDPOINT, CognitiveServicesCredentials(AZURE_CV_KEY))

def _collect_lines(result) -> List[str]:
    lines = []
    # result.analyze_result.read_results is a list of pages
    for page in (result.analyze_result.read_results or []):
        for line in (page.lines or []):
            if line and line.text:
                lines.append(line.text)
    return lines

def read_image(uri: str, *, language: str = "en", poll_interval: float = 0.5, timeout_sec: int = 30) -> str:
    """
    Submit an image URL to Azure Read (OCR) and return all extracted text lines concatenated.
    - uri: public HTTP(S) URL to an image
    - language: "en" by default; "unk" lets the service auto-detect
    """
    # Submit the Read request (async pattern)
    raw = _client.read(url=uri, language=language, raw=True)

    # Operation-Location header contains the operation ID at the end
    op_loc = raw.headers.get("Operation-Location")
    if not op_loc:
        raise RuntimeError("Azure Read did not return Operation-Location header (check endpoint/key/region and URL).")

    operation_id = op_loc.rsplit("/", 1)[-1]  # safer than slicing fixed length

    # Poll for completion
    deadline = time.time() + timeout_sec
    status = None
    while time.time() < deadline:
        result = _client.get_read_result(operation_id)
        status = getattr(result, "status", None)
        if status not in ("notStarted", "running", "NotStarted", "Running"):
            break
        time.sleep(poll_interval)

    if status is None:
        raise RuntimeError("No status from Azure Read result.")

    if status != OperationStatusCodes.succeeded:
        # Common statuses: failed, canceled
        raise RuntimeError(f"Azure OCR did not succeed. Status: {status}")

    # Collect ALL pages/lines, not just the first page
    lines = _collect_lines(result)
    return "\n".join(lines).strip()

